package com.stark.hubselector;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class HubSelector extends JavaPlugin {

    public static NamespacedKey TAG;        // marks hub items
    public static NamespacedKey ARROW_TAG;  // marks teleport arrows

    private final Map<String, ServerEntry> servers = new LinkedHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        TAG = new NamespacedKey(this, "hub_item");
        ARROW_TAG = new NamespacedKey(this, "tp_arrow");

        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
        loadServers();
        getServer().getPluginManager().registerEvents(new HubListener(this), this);

        long interval = Math.max(20L, getConfig().getLong("ping-interval-ticks", 100L));
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::pingAll, 20L, interval);
        Bukkit.getScheduler().runTaskTimer(this, this::refreshOpenGuis, 40L, 40L);
    }

    public void loadServers() {
        servers.clear();
        ConfigurationSection sec = getConfig().getConfigurationSection("servers");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(key);
            if (s == null) continue;
            Material mat = Material.matchMaterial(s.getString("material", "STONE"));
            if (mat == null) {
                getLogger().warning("Invalid material for server '" + key + "'");
                mat = Material.STONE;
            }
            servers.put(key, new ServerEntry(
                    key,
                    s.getInt("slot"),
                    mat,
                    s.getString("name", key),
                    s.getString("server-name", key),
                    s.getString("host", "127.0.0.1"),
                    s.getInt("port", 25565),
                    s.getInt("max-players", 100),
                    s.getStringList("lore")));
        }
        Bukkit.getScheduler().runTaskAsynchronously(this, this::pingAll);
    }

    public Collection<ServerEntry> getServers() {
        return servers.values();
    }

    public ServerEntry getBySlot(int slot) {
        for (ServerEntry e : servers.values()) if (e.slot == slot) return e;
        return null;
    }

    private void pingAll() {
        for (ServerEntry e : servers.values()) {
            try {
                int[] r = ServerPinger.ping(e.host, e.port, 1500);
                e.players = r[0];
                e.liveMax = r[1];
                e.online = true;
            } catch (Exception ex) {
                e.online = false;
                e.players = 0;
            }
        }
    }

    private void refreshOpenGuis() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof SelectorGUI gui) {
                gui.refresh();
            }
        }
    }

    /** Same transfer logic as HubItems: PLUGIN_MESSAGE | COMMAND | BOTH */
    public void transfer(Player player, ServerEntry server) {
        String method = getConfig().getString("transfer-method", "BOTH").toUpperCase();
        String target = server.serverName;

        if (method.equals("PLUGIN_MESSAGE") || method.equals("BOTH")) {
            ByteArrayDataOutput out = ByteStreams.newDataOutput();
            out.writeUTF("Connect");
            out.writeUTF(target);
            player.sendPluginMessage(this, "BungeeCord", out.toByteArray());
        }

        if (method.equals("COMMAND")) {
            runFallback(player, target);
        } else if (method.equals("BOTH")) {
            long delay = Math.max(1L, getConfig().getLong("fallback-delay-ticks", 20L));
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (player.isOnline()) runFallback(player, target);
            }, delay);
        }
    }

    private void runFallback(Player player, String target) {
        String cmd = getConfig().getString("fallback-command", "send %player% %server%")
                .replace("%player%", player.getName())
                .replace("%server%", target);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("hubreload")) {
            reloadConfig();
            loadServers();
            sender.sendMessage("§aHubSelector reloaded.");
            return true;
        }
        return false;
    }
}
