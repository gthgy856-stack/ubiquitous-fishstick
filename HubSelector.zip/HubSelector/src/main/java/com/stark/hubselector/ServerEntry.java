package com.stark.hubselector;

import org.bukkit.Material;

import java.util.List;

public class ServerEntry {
    public final String key;
    public final int slot;
    public final Material material;
    public final String name;
    public final String serverName;
    public final String host;
    public final int port;
    public final int configMax;
    public final List<String> lore;

    public volatile boolean online = false;
    public volatile int players = 0;
    public volatile int liveMax = 0;

    public ServerEntry(String key, int slot, Material material, String name, String serverName,
                       String host, int port, int configMax, List<String> lore) {
        this.key = key;
        this.slot = slot;
        this.material = material;
        this.name = name;
        this.serverName = serverName;
        this.host = host;
        this.port = port;
        this.configMax = configMax;
        this.lore = lore;
    }

    public int max() {
        return online && liveMax > 0 ? liveMax : configMax;
    }
}
