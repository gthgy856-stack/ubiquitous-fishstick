package com.stark.hubselector;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.function.Consumer;

public class HubListener implements Listener {
    private final HubSelector plugin;

    public HubListener(HubSelector plugin) {
        this.plugin = plugin;
    }

    private boolean locked(Player p) {
        return plugin.getConfig().getBoolean("lock-inventory", true) && !p.hasPermission("hubselector.bypass");
    }

    // ───────────── Join: give items ─────────────
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        giveItems(e.getPlayer());
    }

    private void giveItems(Player p) {
        p.getInventory().clear();
        put(p, "bow", Material.BOW, b -> b.enchant(Enchantment.INFINITY, 1).unbreakable());
        put(p, "selector", Material.COMPASS, b -> {});
        put(p, "sword", Material.DIAMOND_SWORD,
                b -> b.enchant(Enchantment.SHARPNESS, 5).enchant(Enchantment.UNBREAKING, 3).unbreakable());
        put(p, "arrow", Material.ARROW, b -> {});
        p.getInventory().setHeldItemSlot(4);
    }

    private void put(Player p, String id, Material m, Consumer<ItemBuilder> extra) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("hotbar." + id);
        if (s == null) return;
        ItemBuilder b = new ItemBuilder(m)
                .name(s.getString("name", " "))
                .lore(s.getStringList("lore"))
                .tag(id);
        extra.accept(b);
        p.getInventory().setItem(s.getInt("slot"), b.build());
    }

    // ───────────── Compass: open GUI ─────────────
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if ("selector".equals(ItemBuilder.id(e.getItem()))) {
            e.setCancelled(true);
            e.getPlayer().openInventory(new SelectorGUI(plugin).getInventory());
        }
    }

    // ───────────── GUI clicks ─────────────
    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;

        if (e.getView().getTopInventory().getHolder() instanceof SelectorGUI) {
            e.setCancelled(true);
            if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
            ServerEntry s = plugin.getBySlot(e.getSlot());
            if (s != null) {
                p.closeInventory();
                p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
                plugin.transfer(p, s);
            }
            return;
        }
        if (locked(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof SelectorGUI) {
            e.setCancelled(true);
            return;
        }
        if (e.getWhoClicked() instanceof Player p && locked(p)) e.setCancelled(true);
    }

    // ───────────── Items can't be dropped / lost ─────────────
    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (!e.getPlayer().hasPermission("hubselector.bypass")) e.setCancelled(true);
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.setKeepInventory(true);
        e.getDrops().clear();
        e.setKeepLevel(true);
        e.setDroppedExp(0);
    }

    // ───────────── Teleport Bow ─────────────
    @EventHandler
    public void onShoot(EntityShootBowEvent e) {
        if (!(e.getEntity() instanceof Player)) return;
        if (!"bow".equals(ItemBuilder.id(e.getBow()))) return;
        e.getProjectile().getPersistentDataContainer()
                .set(HubSelector.ARROW_TAG, PersistentDataType.BYTE, (byte) 1);
    }

    @EventHandler
    public void onHit(ProjectileHitEvent e) {
        Projectile proj = e.getEntity();
        if (!proj.getPersistentDataContainer().has(HubSelector.ARROW_TAG, PersistentDataType.BYTE)) return;

        if (!(proj.getShooter() instanceof Player p)) {
            proj.remove();
            return;
        }

        Location to = proj.getLocation().clone();
        BlockFace face = e.getHitBlockFace();
        if (face != null) {
            to.add(face.getDirection().multiply(0.6));
            if (face == BlockFace.DOWN) to.subtract(0, 1.2, 0);
        }
        to.setYaw(p.getLocation().getYaw());
        to.setPitch(p.getLocation().getPitch());

        proj.remove();
        p.teleport(to);
        p.setFallDistance(0f);
        p.playSound(to, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
    }

    @EventHandler
    public void onArrowDamage(EntityDamageByEntityEvent e) {
        if (e.getDamager().getPersistentDataContainer().has(HubSelector.ARROW_TAG, PersistentDataType.BYTE)) {
            e.setCancelled(true);
        }
    }
}
