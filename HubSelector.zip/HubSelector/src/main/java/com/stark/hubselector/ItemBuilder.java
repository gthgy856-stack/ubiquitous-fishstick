package com.stark.hubselector;

import com.google.common.collect.ArrayListMultimap;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public final class ItemBuilder {
    private final ItemStack item;
    private final ItemMeta meta;

    public ItemBuilder(Material material) {
        this.item = new ItemStack(material);
        this.meta = item.getItemMeta();
    }

    public ItemBuilder amount(int amount) {
        item.setAmount(amount);
        return this;
    }

    public ItemBuilder name(String name) {
        meta.displayName(Util.color(name));
        return this;
    }

    public ItemBuilder lore(List<String> lines) {
        List<net.kyori.adventure.text.Component> out = new ArrayList<>();
        for (String l : lines) out.add(Util.color(l));
        meta.lore(out);
        return this;
    }

    public ItemBuilder enchant(Enchantment e, int level) {
        meta.addEnchant(e, level, true);
        return this;
    }

    public ItemBuilder unbreakable() {
        meta.setUnbreakable(true);
        return this;
    }

    public ItemBuilder tag(String id) {
        meta.getPersistentDataContainer().set(HubSelector.TAG, PersistentDataType.STRING, id);
        return this;
    }

    public ItemStack build() {
        // Empty attribute list + all flags => no "+7 Attack Damage" / enchant lines etc.
        meta.setAttributeModifiers(ArrayListMultimap.<Attribute, AttributeModifier>create());
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    /** Returns the hub item id (bow / selector / sword / arrow) or null. */
    public static String id(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(HubSelector.TAG, PersistentDataType.STRING);
    }
}
