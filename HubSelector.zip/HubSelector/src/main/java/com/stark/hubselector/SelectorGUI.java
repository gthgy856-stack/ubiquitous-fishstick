package com.stark.hubselector;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class SelectorGUI implements InventoryHolder {
    private static final int SIZE = 45; // 5 rows

    private final HubSelector plugin;
    private final Inventory inventory;

    public SelectorGUI(HubSelector plugin) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, SIZE,
                Util.color(plugin.getConfig().getString("gui.title", "&8Server Selector")));
        fill();
        refresh();
    }

    private void fill() {
        ItemStack lime = new ItemBuilder(Material.LIME_STAINED_GLASS_PANE).name(" ").build();
        ItemStack gray = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < SIZE; i++) {
            int r = i / 9, c = i % 9;
            boolean border = r == 0 || r == 4 || c == 0 || c == 8;
            inventory.setItem(i, (border || (r + c) % 2 == 0) ? lime : gray);
        }
    }

    /** Re-draws the server items (player count / status). */
    public void refresh() {
        for (ServerEntry e : plugin.getServers()) {
            if (e.slot < 0 || e.slot >= SIZE) continue;
            List<String> lore = new ArrayList<>();
            for (String line : e.lore) {
                lore.add(line
                        .replace("%players%", String.valueOf(e.players))
                        .replace("%max%", String.valueOf(e.max()))
                        .replace("%status%", e.online ? "&aOnline" : "&cOffline"));
            }
            inventory.setItem(e.slot, new ItemBuilder(e.material)
                    .name(e.name)
                    .lore(lore)
                    .tag("server")
                    .build());
        }
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
