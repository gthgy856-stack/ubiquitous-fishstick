package com.stark.hubselector;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Minimal Minecraft Server List Ping. Returns {online, max}. */
public final class ServerPinger {
    private ServerPinger() {}

    public static int[] ping(String host, int port, int timeoutMs) throws IOException {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), timeoutMs);
            socket.setSoTimeout(timeoutMs);

            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            DataOutputStream h = new DataOutputStream(hb);
            writeVarInt(h, 0x00);
            writeVarInt(h, 767);
            byte[] hostBytes = host.getBytes(StandardCharsets.UTF_8);
            writeVarInt(h, hostBytes.length);
            h.write(hostBytes);
            h.writeShort(port);
            writeVarInt(h, 1);

            writeVarInt(out, hb.size());
            out.write(hb.toByteArray());
            writeVarInt(out, 1);
            writeVarInt(out, 0x00);
            out.flush();

            readVarInt(in); // packet length
            int id = readVarInt(in);
            if (id != 0x00) throw new IOException("Bad packet id " + id);
            int len = readVarInt(in);
            byte[] data = new byte[len];
            in.readFully(data);

            JsonObject json = JsonParser.parseString(new String(data, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject players = json.getAsJsonObject("players");
            return new int[]{players.get("online").getAsInt(), players.get("max").getAsInt()};
        }
    }

    private static void writeVarInt(DataOutputStream out, int value) throws IOException {
        while ((value & ~0x7F) != 0) {
            out.writeByte((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        out.writeByte(value);
    }

    private static int readVarInt(DataInputStream in) throws IOException {
        int result = 0, shift = 0;
        while (true) {
            int b = in.readByte();
            result |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) break;
            shift += 7;
            if (shift > 35) throw new IOException("VarInt too big");
        }
        return result;
    }
}
